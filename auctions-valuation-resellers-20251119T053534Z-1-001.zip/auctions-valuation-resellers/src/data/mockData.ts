import { Auction } from '../types';

export const mockAuctions: Auction[] = [
  {
    id: '1',
    facilityName: 'SecureStore Russellville',
    address: '1245 Main St',
    city: 'Russellville',
    state: 'AR',
    date: '2025-10-15',
    time: '10:00 AM',
    lienAmount: 850,
    distance: 12,
    lat: 35.2784,
    lng: -93.1338,
    unitNumber: 'A-47',
    description: 'Furniture, boxes, household items'
  },
  {
    id: '2',
    facilityName: 'Lake Charles Storage',
    address: '789 Commerce Blvd',
    city: 'Lake Charles',
    state: 'LA',
    date: '2025-10-18',
    time: '2:00 PM',
    lienAmount: 1200,
    distance: 45,
    lat: 30.2266,
    lng: -93.2174,
    unitNumber: 'B-23',
    description: 'Antiques, collectibles, vintage items'
  },
  {
    id: '3',
    facilityName: 'Charlotte Premium Storage',
    address: '456 Trade St',
    city: 'Charlotte',
    state: 'NC',
    date: '2025-10-20',
    time: '11:00 AM',
    lienAmount: 950,
    distance: 78,
    lat: 35.2271,
    lng: -80.8431,
    unitNumber: 'C-12',
    description: 'Electronics, furniture, personal items'
  }
];
