import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Upload, Camera, AlertTriangle, CheckCircle, XCircle, Loader2, Save, Calendar, MapPin } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AnalysisResult {
  items: Array<{
    name: string;
    confidence: number;
    reason: string;
    shouldRescue: boolean;
  }>;
  overallRisk: 'low' | 'medium' | 'high';
  summary: string;
}

interface AuctionPhotoScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved?: () => void;
}

export const AuctionPhotoScanner: React.FC<AuctionPhotoScannerProps> = ({ isOpen, onClose, onSaved }) => {
  const [imageUrl, setImageUrl] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [showSaveForm, setShowSaveForm] = useState(false);
  const [saveData, setSaveData] = useState({
    title: '',
    location: '',
    auctionDate: '',
    notes: ''
  });


  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setResult(null);
      setError('');
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageUrl(e.target.value);
    setPreviewUrl(e.target.value);
    setResult(null);
    setError('');
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError('');
    setResult(null);

    try {
      let urlToAnalyze = imageUrl;

      if (imageFile && !imageUrl) {
        const reader = new FileReader();
        reader.readAsDataURL(imageFile);
        await new Promise((resolve) => {
          reader.onloadend = () => {
            urlToAnalyze = reader.result as string;
            resolve(null);
          };
        });
      }

      const { data, error: functionError } = await supabase.functions.invoke('analyze-auction-photos', {
        body: { imageUrl: urlToAnalyze }
      });

      if (functionError) throw functionError;
      if (data.error) throw new Error(data.error);

      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Failed to analyze image');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveAuction = async () => {
    if (!result || !saveData.title) {
      setError('Please provide a title for this auction');
      return;
    }

    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error: insertError } = await supabase.from('saved_auctions').insert({
        user_id: user.id,
        title: saveData.title,
        location: saveData.location,
        auction_date: saveData.auctionDate || null,
        image_url: previewUrl,
        analysis_result: result,
        overall_risk: result.overallRisk,
        notes: saveData.notes,
        is_bookmarked: true
      });

      if (insertError) throw insertError;

      setShowSaveForm(false);
      setSaveData({ title: '', location: '', auctionDate: '', notes: '' });
      if (onSaved) onSaved();
      alert('Auction saved successfully!');
    } catch (err: any) {
      setError(err.message || 'Failed to save auction');
    } finally {
      setIsSaving(false);
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-amber-600 bg-amber-50';
      default: return 'text-green-600 bg-green-50';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Camera className="w-6 h-6 text-purple-600" />
            <span>Scan Auction Photos</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              Upload photos from storage facility auction listings to detect potential sentimental items before bidding.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Upload Image</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-purple-400 transition">
                <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" id="file-upload" />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="w-12 h-12 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600">Click to upload or drag and drop</p>
                  <p className="text-xs text-gray-500 mt-1">PNG, JPG up to 10MB</p>
                </label>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <div className="flex-1 h-px bg-gray-300"></div>
              <span className="text-sm text-gray-500">OR</span>
              <div className="flex-1 h-px bg-gray-300"></div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Image URL</label>
              <input type="url" value={imageUrl} onChange={handleUrlChange} placeholder="https://example.com/auction-photo.jpg" className="w-full px-4 py-2 border rounded-lg" />
            </div>
          </div>

          {previewUrl && (
            <div className="border rounded-lg overflow-hidden">
              <img src={previewUrl} alt="Preview" className="w-full h-64 object-cover" />
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start space-x-2">
              <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-900">{error}</p>
            </div>
          )}

          {result && (
            <div className="space-y-4">
              <div className={`rounded-lg p-4 ${getRiskColor(result.overallRisk)}`}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">Overall Risk Assessment</h3>
                  <span className="uppercase text-xs font-bold">{result.overallRisk}</span>
                </div>
                <p className="text-sm">{result.summary}</p>
              </div>

              {result.items.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-3">Detected Items ({result.items.length})</h3>
                  <div className="space-y-2">
                    {result.items.map((item, idx) => (
                      <div key={idx} className="border rounded-lg p-4 bg-white">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            {item.shouldRescue ? (
                              <AlertTriangle className="w-5 h-5 text-amber-600" />
                            ) : (
                              <CheckCircle className="w-5 h-5 text-green-600" />
                            )}
                            <h4 className="font-medium">{item.name}</h4>
                          </div>
                          <span className="text-sm font-semibold text-purple-600">{item.confidence}% confident</span>
                        </div>
                        <p className="text-sm text-gray-600">{item.reason}</p>
                        {item.shouldRescue && (
                          <div className="mt-2 bg-amber-50 border border-amber-200 rounded px-3 py-1 text-xs text-amber-800">
                            ⚠️ Recommended for rescue protocol
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {!showSaveForm ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <Button onClick={() => setShowSaveForm(true)} className="w-full bg-green-600 hover:bg-green-700">
                    <Save className="w-4 h-4 mr-2" />
                    Save This Auction
                  </Button>
                </div>
              ) : (
                <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-3">
                  <h3 className="font-semibold mb-3">Save Auction Details</h3>
                  <div>
                    <label className="block text-sm font-medium mb-1">Title *</label>
                    <input type="text" value={saveData.title} onChange={(e) => setSaveData({...saveData, title: e.target.value})} placeholder="Storage Unit #123 - Main St" className="w-full px-3 py-2 border rounded-lg text-sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium mb-1">Location</label>
                      <input type="text" value={saveData.location} onChange={(e) => setSaveData({...saveData, location: e.target.value})} placeholder="Little Rock, AR" className="w-full px-3 py-2 border rounded-lg text-sm" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Auction Date</label>
                      <input type="date" value={saveData.auctionDate} onChange={(e) => setSaveData({...saveData, auctionDate: e.target.value})} className="w-full px-3 py-2 border rounded-lg text-sm" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Notes</label>
                    <textarea value={saveData.notes} onChange={(e) => setSaveData({...saveData, notes: e.target.value})} placeholder="Add any notes about this auction..." className="w-full px-3 py-2 border rounded-lg text-sm" rows={2} />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleSaveAuction} disabled={isSaving || !saveData.title} className="flex-1 bg-green-600 hover:bg-green-700">
                      {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                      Save
                    </Button>
                    <Button variant="outline" onClick={() => setShowSaveForm(false)}>Cancel</Button>
                  </div>
                </div>
              )}
            </div>
          )}


          <div className="flex justify-end space-x-3">
            <Button variant="outline" onClick={onClose}>Close</Button>
            <Button onClick={handleAnalyze} disabled={!previewUrl || isAnalyzing} className="bg-purple-600 hover:bg-purple-700">
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Camera className="w-4 h-4 mr-2" />
                  Analyze Photo
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
