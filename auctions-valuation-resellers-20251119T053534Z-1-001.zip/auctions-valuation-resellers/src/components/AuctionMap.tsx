import React from 'react';
import { MapPin, Navigation2 } from 'lucide-react';
import { Auction } from '../types';

interface AuctionMapProps {
  auctions: Auction[];
  onAuctionClick: (auction: Auction) => void;
}

export const AuctionMap: React.FC<AuctionMapProps> = ({ auctions, onAuctionClick }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 p-4 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Navigation2 className="w-6 h-6" />
            <h2 className="text-xl font-bold">Auctions Within 100 Miles</h2>
          </div>
          <span className="bg-amber-500 px-3 py-1 rounded-full text-sm font-bold">
            {auctions.length} Active
          </span>
        </div>
      </div>

      <div className="relative h-96 bg-gradient-to-br from-purple-100 to-blue-100 p-8">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="w-16 h-16 text-purple-600 mx-auto mb-4 animate-bounce" />
            <p className="text-gray-600 font-semibold">Interactive Map View</p>
            <p className="text-sm text-gray-500 mt-2">Geolocation API Integration</p>
          </div>
        </div>

        {auctions.slice(0, 3).map((auction, idx) => (
          <div key={auction.id} onClick={() => onAuctionClick(auction)} className="absolute bg-white rounded-lg shadow-lg p-3 cursor-pointer hover:shadow-xl transition" style={{ top: `${20 + idx * 30}%`, left: `${15 + idx * 25}%` }}>
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-red-600" />
              <div>
                <p className="font-bold text-sm">{auction.facilityName}</p>
                <p className="text-xs text-gray-600">{auction.distance} mi</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
