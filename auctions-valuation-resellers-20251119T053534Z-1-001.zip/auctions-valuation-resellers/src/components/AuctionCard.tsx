import React from 'react';
import { MapPin, Calendar, DollarSign, Navigation } from 'lucide-react';
import { Auction } from '../types';

interface AuctionCardProps {
  auction: Auction;
  onClick: () => void;
}

export const AuctionCard: React.FC<AuctionCardProps> = ({ auction, onClick }) => {
  return (
    <div onClick={onClick} className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all cursor-pointer border border-gray-200 overflow-hidden">
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 p-4 text-white">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-bold text-lg">{auction.facilityName}</h3>
            <p className="text-sm text-purple-200">Unit {auction.unitNumber}</p>
          </div>
          <div className="bg-amber-500 px-3 py-1 rounded-full text-xs font-bold">
            {auction.distance} mi
          </div>
        </div>
      </div>

      <div className="p-4 space-y-3">
        <div className="flex items-center text-sm text-gray-600">
          <MapPin className="w-4 h-4 mr-2 text-purple-600" />
          <span>{auction.city}, {auction.state}</span>
        </div>

        <div className="flex items-center text-sm text-gray-600">
          <Calendar className="w-4 h-4 mr-2 text-purple-600" />
          <span>{auction.date} at {auction.time}</span>
        </div>

        <div className="flex items-center text-sm text-gray-600">
          <DollarSign className="w-4 h-4 mr-2 text-purple-600" />
          <span className="font-semibold">Lien: ${auction.lienAmount.toLocaleString()}</span>
        </div>

        <p className="text-sm text-gray-500 pt-2 border-t">{auction.description}</p>

        <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg font-semibold transition flex items-center justify-center space-x-2">
          <Navigation className="w-4 h-4" />
          <span>Get Directions</span>
        </button>
      </div>
    </div>
  );
};
